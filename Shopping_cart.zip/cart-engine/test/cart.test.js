'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { openDatabase } = require('../src/db');
const { createApp } = require('../src/app');

let server, base, db;

// Minimal cookie-aware client so session carts persist across calls.
function client() {
  let cookie = '';
  return async (method, path, body) => {
    const res = await fetch(base + path, {
      method,
      headers: { 'content-type': 'application/json', ...(cookie && { cookie }) },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null };
  };
}

before(async () => {
  db = openDatabase(':memory:');
  db.prepare("INSERT INTO coupons (code, percent_off, min_subtotal_cents) VALUES ('SAVE10', 10, 100000)").run();
  const app = createApp(db, { taxRate: 0.18 });
  await new Promise((r) => (server = app.listen(0, r)));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => server.close());

async function seedProduct(api, over = {}) {
  const sku = over.sku || 'SKU-' + Math.random().toString(36).slice(2, 8);
  const r = await api('POST', '/api/products', { sku, name: 'Widget', price: 100, stock: 10, ...over });
  assert.equal(r.status, 201);
  return r.body;
}

test('product CRUD and validation', async () => {
  const api = client();
  const p = await seedProduct(api, { sku: 'CRUD-1', price: 499.99 });
  assert.equal(p.priceCents, 49999);

  assert.equal((await api('POST', '/api/products', { sku: 'CRUD-1', name: 'Dup', price: 1 })).status, 409);
  assert.equal((await api('POST', '/api/products', { sku: 'X', name: 'Bad', price: -5 })).status, 400);
  assert.equal((await api('POST', '/api/products', { sku: 'X', name: 'Bad', price: 1.234 })).status, 400);
  assert.equal((await api('POST', '/api/products', { sku: 'X', name: '', price: 1 })).status, 400);

  const upd = await api('PATCH', `/api/products/${p.id}`, { price: 10.5, stock: 3 });
  assert.equal(upd.body.priceCents, 1050);
  assert.equal(upd.body.stock, 3);
  assert.equal((await api('PATCH', `/api/products/${p.id}`, { sku: 'NEW' })).status, 400);

  assert.equal((await api('DELETE', `/api/products/${p.id}`)).status, 204);
  assert.equal((await api('GET', '/api/products?q=CRUD')).body.items.length, 0); // soft-deleted hidden
  assert.equal((await api('GET', '/api/products/99999')).status, 404);
});

test('add, merge, update, remove items; totals are exact', async () => {
  const api = client();
  const a = await seedProduct(api, { price: 199.99, stock: 10 });
  const b = await seedProduct(api, { price: 0.1, stock: 10 });

  await api('POST', '/api/cart/items', { productId: a.id, quantity: 2 });
  await api('POST', '/api/cart/items', { productId: a.id, quantity: 1 }); // merges to 3
  let cart = (await api('POST', '/api/cart/items', { productId: b.id, quantity: 3 })).body;

  assert.equal(cart.items.length, 2);
  assert.equal(cart.items[0].quantity, 3);
  // 3*19999 + 3*10 = 60027 ; tax = round(60027*.18)=10805 ; total = 70832
  assert.equal(cart.totals.subtotalCents, 60027);
  assert.equal(cart.totals.taxCents, 10805);
  assert.equal(cart.totals.totalCents, 70832);

  cart = (await api('PATCH', `/api/cart/items/${a.id}`, { quantity: 1 })).body;
  assert.equal(cart.totals.subtotalCents, 19999 + 30);

  cart = (await api('PATCH', `/api/cart/items/${b.id}`, { quantity: 0 })).body; // 0 removes
  assert.equal(cart.items.length, 1);

  cart = (await api('DELETE', `/api/cart/items/${a.id}`)).body;
  assert.equal(cart.items.length, 0);
  assert.equal(cart.totals.totalCents, 0);
  assert.equal((await api('DELETE', `/api/cart/items/${a.id}`)).status, 404);
});

test('rejects invalid quantities, unknown products and over-stock', async () => {
  const api = client();
  const p = await seedProduct(api, { stock: 2 });

  for (const q of [0, -1, 1.5, '3', null]) {
    assert.equal((await api('POST', '/api/cart/items', { productId: p.id, quantity: q })).status, 400, `qty ${q}`);
  }
  assert.equal((await api('POST', '/api/cart/items', { productId: 99999, quantity: 1 })).status, 404);
  assert.equal((await api('POST', '/api/cart/items', { quantity: 1 })).status, 400);

  assert.equal((await api('POST', '/api/cart/items', { productId: p.id, quantity: 2 })).status, 201);
  assert.equal((await api('POST', '/api/cart/items', { productId: p.id, quantity: 1 })).status, 409); // 3 > stock
  assert.equal((await api('PATCH', `/api/cart/items/${p.id}`, { quantity: 5 })).status, 409);
});

test('sessions isolate carts', async () => {
  const one = client();
  const two = client();
  const p = await seedProduct(one, { stock: 5 });
  await one('POST', '/api/cart/items', { productId: p.id, quantity: 2 });
  assert.equal((await two('GET', '/api/cart')).body.items.length, 0);
  assert.equal((await one('GET', '/api/cart')).body.items.length, 1);
});

test('coupon applies discount before tax and enforces minimum', async () => {
  const api = client();
  const cheap = await seedProduct(api, { price: 50, stock: 5 });
  const big = await seedProduct(api, { price: 1000, stock: 5 });

  await api('POST', '/api/cart/items', { productId: cheap.id, quantity: 1 });
  assert.equal((await api('POST', '/api/cart/coupon', { code: 'save10' })).status, 400); // below minimum
  assert.equal((await api('POST', '/api/cart/coupon', { code: 'NOPE' })).status, 404);

  await api('POST', '/api/cart/items', { productId: big.id, quantity: 1 }); // 105000
  const cart = (await api('POST', '/api/cart/coupon', { code: 'save10' })).body;
  assert.equal(cart.totals.subtotalCents, 105000);
  assert.equal(cart.totals.discountCents, 10500);
  assert.equal(cart.totals.taxCents, Math.round(94500 * 0.18)); // 17010
  assert.equal(cart.totals.totalCents, 94500 + 17010);

  const removed = (await api('DELETE', '/api/cart/coupon')).body;
  assert.equal(removed.totals.discountCents, 0);
});

test('checkout decrements stock atomically and locks the cart', async () => {
  const api = client();
  const p = await seedProduct(api, { stock: 5, price: 20 });
  await api('POST', '/api/cart/items', { productId: p.id, quantity: 3 });

  assert.equal((await api('POST', '/api/cart/checkout')).body.status, 'checked_out');
  assert.equal((await api('GET', `/api/products/${p.id}`)).body.stock, 2);

  // Session now gets a fresh, empty cart.
  assert.equal((await api('GET', '/api/cart')).body.items.length, 0);
  assert.equal((await api('POST', '/api/cart/checkout')).status, 400); // empty
});

test('checkout fails whole if stock vanished, leaving stock untouched', async () => {
  const api = client();
  const ok = await seedProduct(api, { stock: 5 });
  const scarce = await seedProduct(api, { stock: 5 });
  await api('POST', '/api/cart/items', { productId: ok.id, quantity: 2 });
  await api('POST', '/api/cart/items', { productId: scarce.id, quantity: 4 });

  await api('PATCH', `/api/products/${scarce.id}`, { stock: 1 }); // someone else bought it

  assert.equal((await api('POST', '/api/cart/checkout')).status, 409);
  assert.equal((await api('GET', `/api/products/${ok.id}`)).body.stock, 5); // rolled back
  assert.equal((await api('GET', '/api/cart')).body.status, 'active');
});

test('price snapshot: cart flags catalogue price changes and refreshes on touch', async () => {
  const api = client();
  const p = await seedProduct(api, { price: 100, stock: 10 });
  await api('POST', '/api/cart/items', { productId: p.id, quantity: 1 });
  await api('PATCH', `/api/products/${p.id}`, { price: 120 });

  let cart = (await api('GET', '/api/cart')).body;
  assert.equal(cart.items[0].unitPriceCents, 10000);
  assert.equal(cart.items[0].priceChanged, true);

  cart = (await api('PATCH', `/api/cart/items/${p.id}`, { quantity: 2 })).body;
  assert.equal(cart.items[0].unitPriceCents, 12000);
  assert.equal(cart.items[0].priceChanged, false);
});

test('cart records: list, filter, abandon stale, delete', async () => {
  const api = client();
  await api('GET', '/api/cart');
  const all = (await api('GET', '/api/carts')).body;
  assert.ok(all.length >= 1);
  assert.equal((await api('GET', '/api/carts?status=bogus')).status, 400);

  db.prepare("UPDATE carts SET updated_at = datetime('now', '-48 hours') WHERE status = 'active'").run();
  const { abandoned } = (await api('POST', '/api/carts/maintenance/abandon-stale', { hours: 24 })).body;
  assert.ok(abandoned >= 1);

  const id = (await api('GET', '/api/carts?status=abandoned')).body[0].id;
  assert.equal((await api('DELETE', `/api/carts/${id}`)).status, 204);
  assert.equal((await api('GET', `/api/carts/${id}`)).status, 404);
});

test('malformed JSON and unknown routes return structured errors', async () => {
  const res = await fetch(base + '/api/products', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{bad' });
  assert.equal(res.status, 400);
  assert.equal((await res.json()).error.code, 'VALIDATION_ERROR');
  assert.equal((await client()('GET', '/nope')).status, 404);
});
