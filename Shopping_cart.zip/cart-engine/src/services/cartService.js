'use strict';

const crypto = require('crypto');
const { notFound, conflict, badRequest } = require('../errors');
const v = require('../validators');

const DEFAULT_TAX_RATE = 0.18; // 18% GST; override via options

/**
 * All money is integer cents (paise) to avoid floating-point drift.
 * Pricing pipeline: subtotal -> coupon discount -> tax on discounted amount -> total.
 */
function calculateTotals(items, coupon, taxRate) {
  const subtotal = items.reduce((s, i) => s + i.unitPriceCents * i.quantity, 0);

  let discount = 0;
  let couponApplied = null;
  if (coupon && coupon.active && subtotal >= coupon.min_subtotal_cents) {
    discount = Math.round((subtotal * coupon.percent_off) / 100);
    couponApplied = coupon.code;
  }
  const taxable = subtotal - discount;
  const tax = Math.round(taxable * taxRate);
  const total = taxable + tax;

  return {
    itemCount: items.reduce((s, i) => s + i.quantity, 0),
    subtotalCents: subtotal,
    discountCents: discount,
    taxCents: tax,
    totalCents: total,
    subtotal: subtotal / 100,
    discount: discount / 100,
    tax: tax / 100,
    total: total / 100,
    taxRate,
    couponApplied,
  };
}

function createCartService(db, { taxRate = DEFAULT_TAX_RATE } = {}) {
  const getCartRow = db.prepare('SELECT * FROM carts WHERE id = ?');

  function requireActiveCart(cartId) {
    const cart = getCartRow.get(cartId);
    if (!cart) throw notFound(`Cart ${cartId} not found`);
    if (cart.status !== 'active') throw conflict(`Cart is ${cart.status} and can no longer be modified`);
    return cart;
  }

  function touch(cartId) {
    db.prepare(`UPDATE carts SET updated_at = datetime('now') WHERE id = ?`).run(cartId);
  }

  function create() {
    const id = crypto.randomUUID();
    db.prepare('INSERT INTO carts (id) VALUES (?)').run(id);
    return view(id);
  }

  function view(cartId) {
    const cart = getCartRow.get(cartId);
    if (!cart) throw notFound(`Cart ${cartId} not found`);

    const rows = db
      .prepare(
        `SELECT ci.product_id, ci.quantity, ci.unit_price_cents, p.sku, p.name, p.stock, p.price_cents AS current_price_cents
           FROM cart_items ci JOIN products p ON p.id = ci.product_id
          WHERE ci.cart_id = ? ORDER BY ci.id`
      )
      .all(cartId);

    const items = rows.map((r) => ({
      productId: r.product_id,
      sku: r.sku,
      name: r.name,
      quantity: r.quantity,
      unitPriceCents: r.unit_price_cents,
      unitPrice: r.unit_price_cents / 100,
      lineTotalCents: r.unit_price_cents * r.quantity,
      lineTotal: (r.unit_price_cents * r.quantity) / 100,
      priceChanged: r.current_price_cents !== r.unit_price_cents,
      inStock: r.stock >= r.quantity,
    }));

    const coupon = cart.coupon_code
      ? db.prepare('SELECT * FROM coupons WHERE code = ?').get(cart.coupon_code)
      : null;

    return {
      id: cart.id,
      status: cart.status,
      createdAt: cart.created_at,
      updatedAt: cart.updated_at,
      items,
      totals: calculateTotals(items, coupon, taxRate),
    };
  }

  function getProduct(productId) {
    const p = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
    if (!p || !p.active) throw notFound(`Product ${productId} not found`);
    return p;
  }

  function addItem(cartId, body) {
    v.requireBody(body);
    const productId = v.positiveInt(body.productId, 'productId');
    const qty = body.quantity === undefined ? 1 : v.positiveInt(body.quantity, 'quantity', { max: v.MAX_QTY_PER_LINE });

    const tx = db.transaction(() => {
      requireActiveCart(cartId);
      const product = getProduct(productId);
      const existing = db
        .prepare('SELECT quantity FROM cart_items WHERE cart_id = ? AND product_id = ?')
        .get(cartId, productId);
      const newQty = (existing ? existing.quantity : 0) + qty;

      if (newQty > v.MAX_QTY_PER_LINE) {
        throw badRequest(`Cannot exceed ${v.MAX_QTY_PER_LINE} units of one product per cart`, { field: 'quantity' });
      }
      if (newQty > product.stock) {
        throw conflict(`Only ${product.stock} unit(s) of "${product.name}" in stock`);
      }

      if (existing) {
        db.prepare('UPDATE cart_items SET quantity = ?, unit_price_cents = ? WHERE cart_id = ? AND product_id = ?')
          .run(newQty, product.price_cents, cartId, productId);
      } else {
        db.prepare('INSERT INTO cart_items (cart_id, product_id, quantity, unit_price_cents) VALUES (?, ?, ?, ?)')
          .run(cartId, productId, newQty, product.price_cents);
      }
      touch(cartId);
    });
    tx();
    return view(cartId);
  }

  /** Sets an absolute quantity. quantity = 0 removes the line. */
  function setQuantity(cartId, productId, body) {
    v.requireBody(body);
    const qty = v.nonNegativeInt(body.quantity, 'quantity');
    if (qty > v.MAX_QTY_PER_LINE) throw badRequest(`quantity must not exceed ${v.MAX_QTY_PER_LINE}`, { field: 'quantity' });

    const tx = db.transaction(() => {
      requireActiveCart(cartId);
      const line = db
        .prepare('SELECT id FROM cart_items WHERE cart_id = ? AND product_id = ?')
        .get(cartId, productId);
      if (!line) throw notFound(`Product ${productId} is not in this cart`);

      if (qty === 0) {
        db.prepare('DELETE FROM cart_items WHERE id = ?').run(line.id);
      } else {
        const product = getProduct(productId);
        if (qty > product.stock) throw conflict(`Only ${product.stock} unit(s) of "${product.name}" in stock`);
        db.prepare('UPDATE cart_items SET quantity = ?, unit_price_cents = ? WHERE id = ?')
          .run(qty, product.price_cents, line.id);
      }
      touch(cartId);
    });
    tx();
    return view(cartId);
  }

  function removeItem(cartId, productId) {
    const tx = db.transaction(() => {
      requireActiveCart(cartId);
      const info = db.prepare('DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?').run(cartId, productId);
      if (info.changes === 0) throw notFound(`Product ${productId} is not in this cart`);
      touch(cartId);
    });
    tx();
    return view(cartId);
  }

  function clear(cartId) {
    const tx = db.transaction(() => {
      requireActiveCart(cartId);
      db.prepare('DELETE FROM cart_items WHERE cart_id = ?').run(cartId);
      db.prepare('UPDATE carts SET coupon_code = NULL WHERE id = ?').run(cartId);
      touch(cartId);
    });
    tx();
    return view(cartId);
  }

  function applyCoupon(cartId, body) {
    v.requireBody(body);
    const code = v.nonEmptyString(body.code, 'code', 32).toUpperCase();
    requireActiveCart(cartId);
    const coupon = db.prepare('SELECT * FROM coupons WHERE code = ? AND active = 1').get(code);
    if (!coupon) throw notFound(`Coupon "${code}" is not valid`);

    const current = view(cartId);
    if (current.totals.subtotalCents < coupon.min_subtotal_cents) {
      throw badRequest(`Coupon requires a minimum subtotal of ${coupon.min_subtotal_cents / 100}`, { field: 'code' });
    }
    db.prepare('UPDATE carts SET coupon_code = ? WHERE id = ?').run(code, cartId);
    touch(cartId);
    return view(cartId);
  }

  function removeCoupon(cartId) {
    requireActiveCart(cartId);
    db.prepare('UPDATE carts SET coupon_code = NULL WHERE id = ?').run(cartId);
    touch(cartId);
    return view(cartId);
  }

  /** Re-validates stock + prices, decrements inventory, locks the cart. All-or-nothing. */
  function checkout(cartId) {
    const tx = db.transaction(() => {
      requireActiveCart(cartId);
      const items = db.prepare('SELECT product_id, quantity FROM cart_items WHERE cart_id = ?').all(cartId);
      if (items.length === 0) throw badRequest('Cart is empty');

      for (const it of items) {
        const product = getProduct(it.product_id);
        const info = db
          .prepare(`UPDATE products SET stock = stock - ?, updated_at = datetime('now') WHERE id = ? AND stock >= ?`)
          .run(it.quantity, it.product_id, it.quantity);
        if (info.changes === 0) {
          throw conflict(`"${product.name}" no longer has enough stock (${product.stock} left)`);
        }
        // Re-price at current catalogue price so the receipt is accurate.
        db.prepare('UPDATE cart_items SET unit_price_cents = ? WHERE cart_id = ? AND product_id = ?')
          .run(product.price_cents, cartId, it.product_id);
      }
      db.prepare(`UPDATE carts SET status = 'checked_out', updated_at = datetime('now') WHERE id = ?`).run(cartId);
    });
    tx();
    return view(cartId);
  }

  function list({ status, limit = 50, offset = 0 } = {}) {
    limit = Math.min(Math.max(parseInt(limit, 10) || 50, 1), 200);
    offset = Math.max(parseInt(offset, 10) || 0, 0);
    if (status && !['active', 'checked_out', 'abandoned'].includes(status)) {
      throw badRequest('status must be active, checked_out or abandoned', { field: 'status' });
    }
    const rows = status
      ? db.prepare('SELECT id FROM carts WHERE status = ? ORDER BY created_at DESC LIMIT ? OFFSET ?').all(status, limit, offset)
      : db.prepare('SELECT id FROM carts ORDER BY created_at DESC LIMIT ? OFFSET ?').all(limit, offset);
    return rows.map((r) => view(r.id));
  }

  /** Housekeeping: mark active carts untouched for N hours as abandoned. */
  function abandonStale(hours = 24) {
    return db
      .prepare(
        `UPDATE carts SET status = 'abandoned'
          WHERE status = 'active' AND updated_at < datetime('now', ?)`
      )
      .run(`-${Math.floor(hours)} hours`).changes;
  }

  function deleteCart(cartId) {
    const info = db.prepare('DELETE FROM carts WHERE id = ?').run(cartId);
    if (info.changes === 0) throw notFound(`Cart ${cartId} not found`);
  }

  return { create, view, addItem, setQuantity, removeItem, clear, applyCoupon, removeCoupon, checkout, list, abandonStale, deleteCart };
}

module.exports = { createCartService, calculateTotals };
