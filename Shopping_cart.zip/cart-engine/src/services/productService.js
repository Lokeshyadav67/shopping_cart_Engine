'use strict';

const { notFound, conflict, badRequest } = require('../errors');
const v = require('../validators');

const toApi = (r) =>
  r && {
    id: r.id,
    sku: r.sku,
    name: r.name,
    description: r.description,
    price: r.price_cents / 100,
    priceCents: r.price_cents,
    stock: r.stock,
    active: !!r.active,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };

function createProductService(db) {
  const getRow = db.prepare('SELECT * FROM products WHERE id = ?');

  function get(id) {
    const row = getRow.get(id);
    if (!row) throw notFound(`Product ${id} not found`);
    return toApi(row);
  }

  function create(body) {
    v.requireBody(body);
    const sku = v.nonEmptyString(body.sku, 'sku', 64);
    const name = v.nonEmptyString(body.name, 'name');
    const description = body.description === undefined ? '' : String(body.description).slice(0, 2000);
    const priceCents = v.priceToCents(body.price);
    const stock = body.stock === undefined ? 0 : v.nonNegativeInt(body.stock, 'stock');
    try {
      const info = db
        .prepare('INSERT INTO products (sku, name, description, price_cents, stock) VALUES (?, ?, ?, ?, ?)')
        .run(sku, name, description, priceCents, stock);
      return get(info.lastInsertRowid);
    } catch (e) {
      if (/UNIQUE constraint/i.test(String(e.message))) throw conflict(`SKU "${sku}" already exists`);
      throw e;
    }
  }

  function list({ q, includeInactive = false, limit = 50, offset = 0 } = {}) {
    limit = Math.min(Math.max(parseInt(limit, 10) || 50, 1), 200);
    offset = Math.max(parseInt(offset, 10) || 0, 0);
    const where = [];
    const params = [];
    if (!includeInactive) where.push('active = 1');
    if (q) {
      where.push('(name LIKE ? OR sku LIKE ?)');
      params.push(`%${q}%`, `%${q}%`);
    }
    const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const total = db.prepare(`SELECT COUNT(*) c FROM products ${clause}`).get(...params).c;
    const rows = db
      .prepare(`SELECT * FROM products ${clause} ORDER BY id LIMIT ? OFFSET ?`)
      .all(...params, limit, offset);
    return { total, limit, offset, items: rows.map(toApi) };
  }

  function update(id, body) {
    v.requireBody(body);
    const current = getRow.get(id);
    if (!current) throw notFound(`Product ${id} not found`);

    const next = {
      name: body.name === undefined ? current.name : v.nonEmptyString(body.name, 'name'),
      description: body.description === undefined ? current.description : String(body.description).slice(0, 2000),
      price_cents: body.price === undefined ? current.price_cents : v.priceToCents(body.price),
      stock: body.stock === undefined ? current.stock : v.nonNegativeInt(body.stock, 'stock'),
      active: body.active === undefined ? current.active : body.active ? 1 : 0,
    };
    if (body.sku !== undefined) throw badRequest('sku cannot be changed', { field: 'sku' });

    db.prepare(
      `UPDATE products SET name=?, description=?, price_cents=?, stock=?, active=?, updated_at=datetime('now') WHERE id=?`
    ).run(next.name, next.description, next.price_cents, next.stock, next.active, id);
    return get(id);
  }

  /** Soft delete: keeps history for carts that already reference the product. */
  function remove(id) {
    const info = db
      .prepare(`UPDATE products SET active = 0, updated_at = datetime('now') WHERE id = ?`)
      .run(id);
    if (info.changes === 0) throw notFound(`Product ${id} not found`);
  }

  return { get, create, list, update, remove };
}

module.exports = { createProductService };
