'use strict';

const { openDatabase } = require('./db');
const { createApp } = require('./app');

const db = openDatabase(process.env.DB_FILE || './cart.db');

// Seed demo data on first run.
if (db.prepare('SELECT COUNT(*) c FROM products').get().c === 0) {
  const ins = db.prepare('INSERT INTO products (sku, name, description, price_cents, stock) VALUES (?, ?, ?, ?, ?)');
  ins.run('KB-001', 'Mechanical Keyboard', 'Hot-swappable, 75% layout', 349900, 25);
  ins.run('MS-002', 'Wireless Mouse', 'Ergonomic, 2.4GHz', 79900, 100);
  ins.run('HD-003', 'USB-C Hub', '7-in-1 adapter', 199950, 40);
  db.prepare('INSERT OR IGNORE INTO coupons (code, percent_off, min_subtotal_cents) VALUES (?, ?, ?)').run('SAVE10', 10, 100000);
}

const port = Number(process.env.PORT) || 3000;
createApp(db).listen(port, () => console.log(`Cart engine listening on http://localhost:${port}`));
