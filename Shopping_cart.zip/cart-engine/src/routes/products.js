'use strict';

const express = require('express');
const { idParam } = require('../validators');

module.exports = function productRoutes(products) {
  const r = express.Router();

  r.get('/', (req, res) => {
    const { q, limit, offset, includeInactive } = req.query;
    res.json(products.list({ q, limit, offset, includeInactive: includeInactive === 'true' }));
  });

  r.post('/', (req, res) => res.status(201).json(products.create(req.body)));

  r.get('/:id', (req, res) => res.json(products.get(idParam(req.params.id))));

  r.patch('/:id', (req, res) => res.json(products.update(idParam(req.params.id), req.body)));

  r.delete('/:id', (req, res) => {
    products.remove(idParam(req.params.id));
    res.status(204).end();
  });

  return r;
};
