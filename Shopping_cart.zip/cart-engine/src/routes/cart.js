'use strict';

const express = require('express');
const { idParam } = require('../validators');

/**
 * Session-backed "current cart" (/api/cart) plus record management by id (/api/carts).
 * The session stores only the cart id; all state lives in SQLite.
 */
module.exports = function cartRoutes(carts) {
  const r = express.Router();

  // Resolve (or lazily create) the session's active cart.
  function currentCartId(req) {
    const existing = req.session.cartId;
    if (existing) {
      try {
        if (carts.view(existing).status === 'active') return existing;
      } catch (_) {
        /* stale id, fall through and create a new cart */
      }
    }
    const created = carts.create();
    req.session.cartId = created.id;
    return created.id;
  }

  // ---- current-session cart ----
  r.get('/cart', (req, res) => res.json(carts.view(currentCartId(req))));

  r.post('/cart/items', (req, res) => res.status(201).json(carts.addItem(currentCartId(req), req.body)));

  r.patch('/cart/items/:productId', (req, res) =>
    res.json(carts.setQuantity(currentCartId(req), idParam(req.params.productId, 'productId'), req.body)));

  r.delete('/cart/items/:productId', (req, res) =>
    res.json(carts.removeItem(currentCartId(req), idParam(req.params.productId, 'productId'))));

  r.delete('/cart', (req, res) => res.json(carts.clear(currentCartId(req))));

  r.post('/cart/coupon', (req, res) => res.json(carts.applyCoupon(currentCartId(req), req.body)));

  r.delete('/cart/coupon', (req, res) => res.json(carts.removeCoupon(currentCartId(req))));

  r.post('/cart/checkout', (req, res) => {
    const receipt = carts.checkout(currentCartId(req));
    delete req.session.cartId; // next request starts a fresh cart
    res.json(receipt);
  });

  // ---- cart records (admin-style management) ----
  r.get('/carts', (req, res) => res.json(carts.list(req.query)));

  r.get('/carts/:id', (req, res) => res.json(carts.view(req.params.id)));

  r.delete('/carts/:id', (req, res) => {
    carts.deleteCart(req.params.id);
    res.status(204).end();
  });

  r.post('/carts/maintenance/abandon-stale', (req, res) => {
    const hours = Number(req.body && req.body.hours) || 24;
    res.json({ abandoned: carts.abandonStale(hours) });
  });

  return r;
};
