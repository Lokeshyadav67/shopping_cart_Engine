'use strict';

const { badRequest } = require('./errors');

const MAX_QTY_PER_LINE = 100;

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function requireBody(body) {
  if (!isPlainObject(body)) throw badRequest('Request body must be a JSON object');
  return body;
}

function positiveInt(value, field, { max } = {}) {
  if (!Number.isInteger(value) || value < 1) {
    throw badRequest(`${field} must be a positive integer`, { field });
  }
  if (max !== undefined && value > max) {
    throw badRequest(`${field} must not exceed ${max}`, { field });
  }
  return value;
}

function nonNegativeInt(value, field) {
  if (!Number.isInteger(value) || value < 0) {
    throw badRequest(`${field} must be a non-negative integer`, { field });
  }
  return value;
}

function nonEmptyString(value, field, maxLen = 200) {
  if (typeof value !== 'string' || value.trim() === '') {
    throw badRequest(`${field} is required and must be a non-empty string`, { field });
  }
  if (value.length > maxLen) {
    throw badRequest(`${field} must be at most ${maxLen} characters`, { field });
  }
  return value.trim();
}

/** Accepts a price in major units (e.g. 499.99) and returns integer cents. */
function priceToCents(value, field = 'price') {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) {
    throw badRequest(`${field} must be a non-negative number`, { field });
  }
  const cents = Math.round(value * 100);
  if (Math.abs(cents / 100 - value) > 1e-9) {
    throw badRequest(`${field} must have at most 2 decimal places`, { field });
  }
  return cents;
}

function idParam(raw, field = 'id') {
  const n = Number(raw);
  if (!Number.isInteger(n) || n < 1) throw badRequest(`${field} must be a positive integer`, { field });
  return n;
}

module.exports = {
  MAX_QTY_PER_LINE,
  requireBody,
  positiveInt,
  nonNegativeInt,
  nonEmptyString,
  priceToCents,
  idParam,
};
