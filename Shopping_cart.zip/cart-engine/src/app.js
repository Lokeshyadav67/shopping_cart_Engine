'use strict';

const path = require('path');
const express = require('express');
const session = require('express-session');
const { AppError } = require('./errors');
const { createProductService } = require('./services/productService');
const { createCartService } = require('./services/cartService');
const productRoutes = require('./routes/products');
const cartRoutes = require('./routes/cart');

function createApp(db, { taxRate, sessionSecret = process.env.SESSION_SECRET || 'dev-only-secret-change-me' } = {}) {
  const app = express();
  const products = createProductService(db);
  const carts = createCartService(db, { taxRate });

  app.use(express.json({ limit: '100kb' }));
  app.use(
    session({
      name: 'cart.sid',
      secret: sessionSecret,
      resave: false,
      saveUninitialized: false,
      cookie: { httpOnly: true, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 24 * 7 },
    })
  );

  app.use(express.static(path.join(__dirname, '..', 'public')));
  app.get('/health', (_req, res) => res.json({ ok: true }));
  app.use('/api/products', productRoutes(products));
  app.use('/api', cartRoutes(carts));

  app.use((req, _res, next) => next(new AppError(404, 'NOT_FOUND', `Route ${req.method} ${req.path} not found`)));

  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    if (err instanceof AppError) {
      return res.status(err.status).json({ error: { code: err.code, message: err.message, details: err.details } });
    }
    if (err.type === 'entity.parse.failed') {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Malformed JSON body' } });
    }
    console.error(err);
    res.status(500).json({ error: { code: 'INTERNAL', message: 'Unexpected server error' } });
  });

  return app;
}

module.exports = { createApp };
