# Shopping Cart Engine

Express.js + SQLite (built-in `node:sqlite`, no native compile needed; requires Node 22.13+) backend for products and shopping carts.

## Run

```bash
npm install
npm start          # http://localhost:3000, creates ./cart.db and seeds 3 products + coupon SAVE10
npm test           # 10 integration tests (in-memory SQLite)
```

Env vars: `PORT`, `DB_FILE`, `SESSION_SECRET` (set this in production).

Open **http://localhost:3000** for the storefront page (product grid, cart, coupon, checkout). The JSON API lives under `/api`.

## Schema

| Table | Purpose |
|---|---|
| `products` | sku (unique), name, `price_cents`, `stock`, `active` (soft delete) |
| `carts` | UUID id, `status` (active / checked_out / abandoned), optional `coupon_code` |
| `cart_items` | one row per (cart, product), `quantity > 0`, `unit_price_cents` snapshot |
| `coupons` | `percent_off`, `min_subtotal_cents`, `active` |

Integrity is enforced twice: CHECK / UNIQUE / FOREIGN KEY constraints in the database, and request validation in `src/validators.js`.

## Pricing

All money is stored as **integer cents**, so there is no floating-point drift.

```
subtotal = Σ unit_price × quantity
discount = round(subtotal × percent_off / 100)     (if coupon valid and minimum met)
tax      = round((subtotal − discount) × tax_rate) (default 18%)
total    = subtotal − discount + tax
```

Adding or updating a line refreshes its `unit_price_cents` from the catalogue; a line whose catalogue price has since changed is flagged `priceChanged: true`. Checkout re-prices and re-checks stock.

## API

The cart is tied to the session cookie (`cart.sid`) via `express-session`; the session holds only the cart id.

**Products**

| Method | Path | Notes |
|---|---|---|
| GET | `/api/products?q=&limit=&offset=` | search and paginate |
| POST | `/api/products` | `{sku, name, price, stock, description?}` price in major units, max 2 decimals |
| GET / PATCH / DELETE | `/api/products/:id` | DELETE is a soft delete; SKU is immutable |

**Current cart**

| Method | Path | Notes |
|---|---|---|
| GET | `/api/cart` | items and totals |
| POST | `/api/cart/items` | `{productId, quantity?}` merges with an existing line |
| PATCH | `/api/cart/items/:productId` | `{quantity}`; `0` removes the line |
| DELETE | `/api/cart/items/:productId` | remove line |
| DELETE | `/api/cart` | empty the cart |
| POST / DELETE | `/api/cart/coupon` | `{code}` |
| POST | `/api/cart/checkout` | atomic: decrements stock, locks the cart |

**Cart records**: `GET /api/carts?status=`, `GET|DELETE /api/carts/:id`, `POST /api/carts/maintenance/abandon-stale {hours}`.

Errors share one shape: `{ "error": { "code", "message", "details" } }` with 400 (validation), 404, or 409 (stock / state conflict).

## Example

```bash
curl -c jar -H 'content-type: application/json' -d '{"productId":1,"quantity":2}' localhost:3000/api/cart/items
curl -b jar -H 'content-type: application/json' -d '{"code":"SAVE10"}' localhost:3000/api/cart/coupon
curl -b jar -X POST localhost:3000/api/cart/checkout
```

## Layout

```
src/db.js                 schema + connection (WAL, foreign keys on)
src/validators.js         input validation helpers
src/services/             productService, cartService (business logic, transactions)
src/routes/               thin HTTP layer
public/index.html         simple storefront UI (vanilla JS)
src/app.js, server.js     wiring and entry point
test/cart.test.js         integration tests
```

## Production notes

- The default `MemoryStore` session store is for development; use a persistent session store (for example one backed by SQLite or Redis) and `cookie.secure = true` behind HTTPS.
- Product-management routes have no auth; add an admin guard before exposing them.
